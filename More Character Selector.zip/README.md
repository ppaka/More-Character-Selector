# More Character Selector

아직 완성되지 않았습니다.
이 모드는 https://github.com/NotAustinVT/LethalCompany_PlayerAvatarLoader 와 https://github.com/x753/Lethal-Company-More-Suits 의존하지만 모델은 https://github.com/BunyaPineTree/LethalCompany_ModelReplacementAPI 에서 지원합니다.

지속적으로 모델을 추가할 예정이며, 첫 시작은 Yue Ling의 Akula (Cozy Winter Edition)모델로 시작합니다.
모델 사용의 허락은 구했지만 상업적 이용이 어디까지 제한되는지 애매하여 다시 메일을 보낸 상태입니다.

그때까지는 무기한 보류입니다.

모델 사용을 허락해주신 Yue Ling님 감사드리며 이 제작자의 모델을 원하시는 분들은 맨 아래의 크래딧의 링크를 찾아가 구매하시기 바랍니다.

(Eng)
Not yet complete.
The mod relies on https://github.com/NotAustinVT/LethalCompany_PlayerAvatarLoader and https://github.com/x753/Lethal-Company-More-Suits, but the models are supported by https://github.com/BunyaPineTree/LethalCompany_ModelReplacementAPI.

We'll be adding models over time, but we're starting with Yue Ling's Akula (Cozy Winter Edition) model.

Thanks to Yue Ling for allowing us to use her model, and if you'd like to purchase a model from this creator, please visit the link in the credits at the bottom.



Cradit
----------------------------------------------------------------------
Yue Ling's Akula (Cozy Winter Edition)-https://yuumaandyueling.booth.pm/items/5344969